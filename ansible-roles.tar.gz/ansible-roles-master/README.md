# ansible-roles
Ansible Roles for Rackspace supported templates
